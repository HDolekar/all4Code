package com.example.musiciplay;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class PlayerActivity extends AppCompatActivity {


    Button btn_next,btn_previous,btn_pause;
    TextView songTextLabel;
    SeekBar songSeekbar;
    String sname;
    private  volatile boolean isSongPlaying;

    static MediaPlayer myMediaPlayer;
    int position;
    ArrayList<File> mySongs;
    Thread updateseekbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);


        btn_next = (Button)findViewById(R.id.next);
        btn_previous = (Button)findViewById(R.id.previous);
        btn_pause = (Button)findViewById(R.id.pause);
        songTextLabel = (TextView)findViewById(R.id.songLabel);
        songSeekbar=(SeekBar)findViewById(R.id.seekbar);


        updateseekbar=new Thread(){

            @Override
            public void run() {


                int totalDuration= myMediaPlayer.getDuration();
               final int currentPosition=0;
                isSongPlaying=true;


                while (currentPosition<totalDuration){

                    try {
                       Thread.sleep(1000);

                    }catch (InterruptedException e){
                        e.printStackTrace();

                        if(isSongPlaying){

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    currentPosition=myMediaPlayer.getCurrentPosition();
                                    songSeekbar.setProgress(currentPosition);

                                }
                            });

                        }
                    }
                }
            }
        };


        if(myMediaPlayer!=null){
            myMediaPlayer.stop();
           myMediaPlayer.release();
        }

        Intent i= getIntent();
        Bundle bundle = i.getExtras();


        mySongs=(ArrayList) bundle.getParcelableArrayList("songs");
        sname=mySongs.get(position).getName().toString();

        String songName = i.getStringExtra("songname");
        songTextLabel.setText(songName);
        songTextLabel.setSelected(true);

        position = bundle.getInt("pos",0);

        Uri u = Uri.parse(mySongs.get(position).toString());

        myMediaPlayer=MediaPlayer.create(getApplicationContext(),u);

        myMediaPlayer.start();
        songSeekbar.setMax(myMediaPlayer.getDuration());


        songSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                myMediaPlayer.seekTo(seekBar.getProgress());

            }
        });



    }
}
